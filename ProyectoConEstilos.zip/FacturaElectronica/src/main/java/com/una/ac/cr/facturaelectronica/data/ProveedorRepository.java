package com.una.ac.cr.facturaelectronica.data;


import com.una.ac.cr.facturaelectronica.logic.ProveedorEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@Transactional
public interface ProveedorRepository extends JpaRepository<ProveedorEntity,String> {
    Optional<ProveedorEntity> findByContrasenaAndIdProveedor(String contrasena, String usuario);
    ProveedorEntity findByIdProveedor(String id);


}

