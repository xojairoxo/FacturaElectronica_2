package com.una.ac.cr.facturaelectronica.logic;

import jakarta.persistence.*;

import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "producto", schema = "facturaelectronica")
public class ProductoEntity {
    @Id
    @Column(name = "producto_id")
    private int productoId;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "descripcion")
    private String descripcion;
    @Basic
    @Column(name = "precio")
    private Double precio;
    @Basic
    @Column(name = "tipo_producto")
    private String tipoProducto;
    @Basic
    @Column(name = "proveedor_id", insertable=false, updatable=false)
    private String proveedorId;
    @OneToMany(mappedBy = "productoByIdProducto")
    private Collection<FacturasProductosEntity> facturasProductosByProductoId;
    @ManyToOne
    @JoinColumn(name = "proveedor_id", referencedColumnName = "id_proveedor")
    private ProveedorEntity proveedorByProveedorId;

    public int getProductoId() {
        return productoId;
    }

    public void setProductoId(int productoId) {
        this.productoId = productoId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public String getTipoProducto() {
        return tipoProducto;
    }

    public void setTipoProducto(String tipoProducto) {
        this.tipoProducto = tipoProducto;
    }

    public String getProveedorId() {
        return proveedorId;
    }

    public void setProveedorId(String proveedorId) {
        this.proveedorId = proveedorId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductoEntity that = (ProductoEntity) o;
        return productoId == that.productoId && Objects.equals(nombre, that.nombre) && Objects.equals(descripcion, that.descripcion) && Objects.equals(precio, that.precio) && Objects.equals(tipoProducto, that.tipoProducto) && Objects.equals(proveedorId, that.proveedorId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(productoId, nombre, descripcion, precio, tipoProducto, proveedorId);
    }

    public Collection<FacturasProductosEntity> getFacturasProductosByProductoId() {
        return facturasProductosByProductoId;
    }

    public void setFacturasProductosByProductoId(Collection<FacturasProductosEntity> facturasProductosByProductoId) {
        this.facturasProductosByProductoId = facturasProductosByProductoId;
    }

    public ProveedorEntity getProveedorByProveedorId() {
        return proveedorByProveedorId;
    }

    public void setProveedorByProveedorId(ProveedorEntity proveedorByProveedorId) {
        this.proveedorByProveedorId = proveedorByProveedorId;
    }
}
