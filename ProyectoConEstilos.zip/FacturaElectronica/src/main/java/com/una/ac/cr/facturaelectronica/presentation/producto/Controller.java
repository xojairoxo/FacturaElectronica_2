package com.una.ac.cr.facturaelectronica.presentation.producto;


import com.una.ac.cr.facturaelectronica.data.ProveedorRepository;
import com.una.ac.cr.facturaelectronica.logic.ProductoEntity;
import com.una.ac.cr.facturaelectronica.service.ProductoService;
import com.una.ac.cr.facturaelectronica.service.ProveedorService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@org.springframework.stereotype.Controller("producto")
public class Controller {
    @Autowired
    ProductoService productoService;
    @Autowired
    private ProveedorService proveedorService;
    @GetMapping("/presentation/producto/show")
    public String show(Model model, HttpSession session){
        String idProveedor = (String) session.getAttribute("idProveedor");
        model.addAttribute("productos", productoService.productoFindAllByProveedorId(idProveedor));
        return "/presentation/proveedorLogin/producto/listarProductos";
    }

    @GetMapping("/presentation/producto/register")
    public String register() {
        return "/presentation/proveedorLogin/producto/View";
    }
    @PostMapping("/presentation/producto/add")
    public String add(@ModelAttribute ProductoEntity producto, HttpSession session){
        String idProveedor = (String) session.getAttribute("idProveedor");
        producto.setProveedorId(idProveedor);
        producto.setProveedorByProveedorId(proveedorService.proveedorById(idProveedor));
        productoService.productoSave(producto);
        return "redirect:/presentation/producto/show";
    }
}
