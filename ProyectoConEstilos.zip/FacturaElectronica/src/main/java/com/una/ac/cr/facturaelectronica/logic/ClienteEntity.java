package com.una.ac.cr.facturaelectronica.logic;

import jakarta.persistence.*;

import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "cliente", schema = "facturaelectronica")
public class ClienteEntity {
    @Id
    @Column(name = "cliente_id")
    private String clienteId;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "direccion")
    private String direccion;
    @Basic
    @Column(name = "tipo_cliente")
    private String tipoCliente;
    @Basic
    @Column(name = "correo_electronico")
    private String correoElectronico;
    @Basic
    @Column(name = "proveedor_id", insertable=false, updatable=false)
    private String proveedorId;
    @ManyToOne
    @JoinColumn(name = "proveedor_id", referencedColumnName = "id_proveedor", nullable = false)
    private ProveedorEntity proveedorByProveedorId;
    @OneToMany(mappedBy = "clienteByCliente")
    private Collection<FacturaEntity> facturasByClienteId;

    public String getClienteId() {
        return clienteId;
    }

    public void setClienteId(String clienteId) {
        this.clienteId = clienteId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(String tipoCliente) {
        this.tipoCliente = tipoCliente;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getProveedorId() {
        return proveedorId;
    }

    public void setProveedorId(String proveedorId) {
        this.proveedorId = proveedorId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClienteEntity that = (ClienteEntity) o;
        return Objects.equals(clienteId, that.clienteId) && Objects.equals(nombre, that.nombre) && Objects.equals(direccion, that.direccion) && Objects.equals(tipoCliente, that.tipoCliente) && Objects.equals(correoElectronico, that.correoElectronico) && Objects.equals(proveedorId, that.proveedorId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(clienteId, nombre, direccion, tipoCliente, correoElectronico, proveedorId);
    }

    public ProveedorEntity getProveedorByProveedorId() {
        return proveedorByProveedorId;
    }

    public void setProveedorByProveedorId(ProveedorEntity proveedorByProveedorId) {
        this.proveedorByProveedorId = proveedorByProveedorId;
    }

    public Collection<FacturaEntity> getFacturasByClienteId() {
        return facturasByClienteId;
    }

    public void setFacturasByClienteId(Collection<FacturaEntity> facturasByClienteId) {
        this.facturasByClienteId = facturasByClienteId;
    }
}
