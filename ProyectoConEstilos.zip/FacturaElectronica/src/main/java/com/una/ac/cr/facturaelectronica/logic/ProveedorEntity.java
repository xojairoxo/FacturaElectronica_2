package com.una.ac.cr.facturaelectronica.logic;

import jakarta.persistence.*;

import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "proveedor", schema = "facturaelectronica")
public class ProveedorEntity {
    @Id
    @Column(name = "id_proveedor")
    private String idProveedor;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "correo_electronico")
    private String correoElectronico;
    @Basic
    @Column(name = "contrasena")
    private String contrasena;
    @Basic
    @Column(name = "activo")
    private Byte activo;
    @Basic
    @Column(name = "telefono")
    private Integer telefono;
    @Basic
    @Column(name = "direccion")
    private String direccion;
    @Basic
    @Column(name = "tipo_proveedor")
    private String tipoProveedor;
    @OneToMany(mappedBy = "proveedorByProveedorId")
    private Collection<ClienteEntity> clientesByIdProveedor;
    @OneToMany(mappedBy = "proveedorByProveedorId")
    private Collection<ProductoEntity> productosByIdProveedor;

    public String getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(String idProveedor) {
        this.idProveedor = idProveedor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public Byte getActivo() {
        return activo;
    }

    public void setActivo(Byte activo) {
        this.activo = activo;
    }

    public Integer getTelefono() {
        return telefono;
    }

    public void setTelefono(Integer telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTipoProveedor() {
        return tipoProveedor;
    }

    public void setTipoProveedor(String tipoProveedor) {
        this.tipoProveedor = tipoProveedor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProveedorEntity that = (ProveedorEntity) o;
        return Objects.equals(idProveedor, that.idProveedor) && Objects.equals(nombre, that.nombre) && Objects.equals(correoElectronico, that.correoElectronico) && Objects.equals(contrasena, that.contrasena) && Objects.equals(activo, that.activo) && Objects.equals(telefono, that.telefono) && Objects.equals(direccion, that.direccion) && Objects.equals(tipoProveedor, that.tipoProveedor);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProveedor, nombre, correoElectronico, contrasena, activo, telefono, direccion, tipoProveedor);
    }

    public Collection<ClienteEntity> getClientesByIdProveedor() {
        return clientesByIdProveedor;
    }

    public void setClientesByIdProveedor(Collection<ClienteEntity> clientesByIdProveedor) {
        this.clientesByIdProveedor = clientesByIdProveedor;
    }

    public Collection<ProductoEntity> getProductosByIdProveedor() {
        return productosByIdProveedor;
    }

    public void setProductosByIdProveedor(Collection<ProductoEntity> productosByIdProveedor) {
        this.productosByIdProveedor = productosByIdProveedor;
    }
}
