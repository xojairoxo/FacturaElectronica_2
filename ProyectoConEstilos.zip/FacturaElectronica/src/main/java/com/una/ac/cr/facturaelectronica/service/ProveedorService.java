package com.una.ac.cr.facturaelectronica.service;

import com.una.ac.cr.facturaelectronica.data.ProveedorRepository;
import com.una.ac.cr.facturaelectronica.logic.ClienteEntity;
import com.una.ac.cr.facturaelectronica.logic.ProveedorEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProveedorService {
    @Autowired
    private ProveedorRepository proveedorRepository;
    List<ClienteEntity> clientes;
    public Iterable<ProveedorEntity> proveedorFindAll(){
        return proveedorRepository.findAll();
    }
    public Optional<ProveedorEntity> proveedorLogin(String usuario, String contrasena){
        return proveedorRepository.findByContrasenaAndIdProveedor(contrasena, usuario);
    }
    public void proveedorSave(ProveedorEntity proveedor){
        proveedorRepository.save(proveedor);
    }
    public ProveedorEntity proveedorById(String id){
      return  proveedorRepository.findByIdProveedor(id);
    }

}
