package com.una.ac.cr.facturaelectronica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturaElectronicaApplicationTests {

    @Test
    void contextLoads() {
    }

}
